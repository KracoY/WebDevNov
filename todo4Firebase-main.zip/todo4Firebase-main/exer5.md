1. Create the boxes we need to create
2. Create the banner background image
3. Create the header
4. Create the input section
5. Create the todoItems list sectoin
6. Set up our database
7. Create the ability to save data in a firebase database
8. Create the funcionality to grab the data from the databas
9. Create the funcionality to update the data with the new status of completed or active